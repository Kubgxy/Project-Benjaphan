declare module "react-image-magnify" {
    const ReactImageMagnify: any;
    export default ReactImageMagnify;
  }
  